﻿namespace gemeinsameTexte;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();

        Routing.RegisterRoute(nameof(Views.TextPage), typeof(Views.TextPage));
    }
}
