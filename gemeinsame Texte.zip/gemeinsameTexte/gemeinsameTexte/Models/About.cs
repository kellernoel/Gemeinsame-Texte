﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gemeinsameTexte.Models
{
    internal class About
    {
        public string Title => "This app is made by Noel Keller";

        public string email => "noel_keller@icloud.com";

        public string tele => "+41 78 695 03 95";
    }
}
